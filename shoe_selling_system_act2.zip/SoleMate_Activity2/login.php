<?php
require_once 'config.php';
if (is_logged_in()) redirect('index.php');
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $email = strtolower(trim($_POST['email'] ?? ''));
    $stmt = $pdo->prepare("SELECT id,name,email,password,role FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();
    if ($user && password_verify($_POST['password'] ?? '', $user['password'])) {
        session_regenerate_id(true);
        unset($user['password']);
        $_SESSION['user'] = $user;
        set_flash('Welcome back, ' . $user['name'] . '!');
        redirect($user['role'] === 'admin' ? 'admin.php' : 'index.php');
    }
    $error = 'Invalid email or password.';
}
$page_title = 'Login';
require 'header.php';
?>
<div class="form-card">
<h1>Log In</h1>
<?php if ($error): ?><div class="alert error"><?= e($error) ?></div><?php endif; ?>
<form method="post">
<?= csrf_field() ?>
<label>Email<input type="email" name="email" required></label>
<label>Password<input type="password" name="password" required></label>
<button class="full">Log In</button>
</form>
<p>New customer? <a href="register.php">Create an account</a>.</p>
</div>
<?php require 'footer.php'; ?>
