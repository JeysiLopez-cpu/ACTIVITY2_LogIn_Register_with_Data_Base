<?php
require_once 'config.php';
if (!isset($_SESSION['cart'])) $_SESSION['cart'] = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = $_POST['action'] ?? '';
    $id = (int)($_POST['product_id'] ?? 0);
    if ($action === 'add' && $id > 0) {
        $stmt = $pdo->prepare("SELECT id,stock FROM products WHERE id=? AND is_active=1");
        $stmt->execute([$id]);
        $p = $stmt->fetch();
        if ($p && $p['stock'] > 0) {
            $_SESSION['cart'][$id] = min((int)($_SESSION['cart'][$id] ?? 0) + 1, (int)$p['stock']);
            set_flash('Shoe added to cart.');
        }
    } elseif ($action === 'update') {
        foreach (($_POST['qty'] ?? []) as $pid => $qty) {
            $pid = (int)$pid; $qty = max(0, (int)$qty);
            $stmt = $pdo->prepare("SELECT stock FROM products WHERE id=? AND is_active=1");
            $stmt->execute([$pid]); $p = $stmt->fetch();
            if (!$p || $qty === 0) unset($_SESSION['cart'][$pid]);
            else $_SESSION['cart'][$pid] = min($qty, (int)$p['stock']);
        }
        set_flash('Cart updated.');
    } elseif ($action === 'remove') {
        unset($_SESSION['cart'][$id]);
        set_flash('Item removed.');
    }
    redirect('cart.php');
}
$items = []; $total = 0;
if ($_SESSION['cart']) {
    $ids = array_map('intval', array_keys($_SESSION['cart']));
    $marks = implode(',', array_fill(0, count($ids), '?'));
    $stmt = $pdo->prepare("SELECT * FROM products WHERE is_active=1 AND id IN ($marks)");
    $stmt->execute($ids);
    foreach ($stmt->fetchAll() as $p) {
        $qty = min((int)$_SESSION['cart'][$p['id']], (int)$p['stock']);
        if ($qty < 1) continue;
        $p['qty'] = $qty; $p['line_total'] = $qty * (float)$p['price'];
        $items[] = $p; $total += $p['line_total'];
    }
}
$page_title = 'Shopping Cart';
require 'header.php';
?>
<h1>Your Shopping Cart</h1>
<?php if (!$items): ?><p>Your cart is empty. <a href="index.php">Browse shoes</a>.</p><?php else: ?>
<form method="post">
<?= csrf_field() ?><input type="hidden" name="product_id" value="">
<table><tr><th>Shoe</th><th>Price</th><th>Quantity</th><th>Subtotal</th><th></th></tr>
<?php foreach ($items as $p): ?>
<tr>
<td><?= e($p['name']) ?></td><td>₱<?= number_format((float)$p['price'],2) ?></td>
<td><input class="qty" type="number" min="0" max="<?= (int)$p['stock'] ?>" name="qty[<?= (int)$p['id'] ?>]" value="<?= (int)$p['qty'] ?>"></td>
<td>₱<?= number_format($p['line_total'],2) ?></td>
<td><button class="danger" name="action" value="remove" formaction="cart.php" formmethod="post" onclick="this.form.product_id.value='<?= (int)$p['id'] ?>'">Remove</button></td>
</tr>
<?php endforeach; ?>
</table>
<p class="total">Total: ₱<?= number_format($total,2) ?></p>
<button name="action" value="update">Update Cart</button> <a class="button" href="checkout.php">Proceed to Checkout</a>
</form>
<?php endif; ?>
<?php require 'footer.php'; ?>
