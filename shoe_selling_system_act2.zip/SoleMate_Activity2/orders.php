<?php
require_once 'config.php';
require_login();
$stmt = $pdo->prepare("SELECT * FROM orders WHERE user_id=? ORDER BY created_at DESC");
$stmt->execute([current_user()['id']]);
$orders = $stmt->fetchAll();
$page_title = 'My Orders';
require 'header.php';
?>
<h1>My Orders</h1>
<?php if (!$orders): ?><p>You have not placed an order yet.</p><?php endif; ?>
<?php foreach ($orders as $order): ?>
<section class="panel">
<h3>Order #<?= (int)$order['id'] ?> <span class="status"><?= e($order['status']) ?></span></h3>
<p><?= e($order['created_at']) ?> · ₱<?= number_format((float)$order['total_amount'],2) ?></p>
<p><?= e($order['shipping_address']) ?> · <?= e($order['phone']) ?></p>
<?php
$itemsStmt = $pdo->prepare("SELECT product_name,quantity,price FROM order_items WHERE order_id=?");
$itemsStmt->execute([$order['id']]);
foreach ($itemsStmt->fetchAll() as $item):
?>
<p><?= e($item['product_name']) ?> × <?= (int)$item['quantity'] ?> — ₱<?= number_format((float)$item['price'],2) ?></p>
<?php endforeach; ?>
</section>
<?php endforeach; ?>
<?php require 'footer.php'; ?>
