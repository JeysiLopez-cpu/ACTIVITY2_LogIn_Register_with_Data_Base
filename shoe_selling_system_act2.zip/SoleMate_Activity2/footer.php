</main>
<footer class="footer">© <?= date('Y') ?> SoleMate Shoe Store. All rights reserved.</footer>
</body>
</html>
