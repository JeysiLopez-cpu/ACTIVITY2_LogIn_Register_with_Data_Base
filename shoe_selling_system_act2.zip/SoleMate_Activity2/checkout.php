<?php
require_once 'config.php';
require_login();
$cart = $_SESSION['cart'] ?? [];
if (!$cart) { set_flash('Your cart is empty.', 'error'); redirect('cart.php'); }
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $address = trim($_POST['shipping_address'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    if ($address === '' || $phone === '') {
        $error = 'Shipping address and phone number are required.';
    } else {
        try {
            $pdo->beginTransaction();
            $ids = array_map('intval', array_keys($cart));
            $marks = implode(',', array_fill(0, count($ids), '?'));
            $stmt = $pdo->prepare("SELECT * FROM products WHERE is_active=1 AND id IN ($marks) FOR UPDATE");
            $stmt->execute($ids);
            $products = [];
            foreach ($stmt->fetchAll() as $p) $products[(int)$p['id']] = $p;
            $total = 0; $lines = [];
            foreach ($cart as $id => $qty) {
                $id = (int)$id; $qty = (int)$qty;
                if (!isset($products[$id]) || $qty < 1 || $qty > (int)$products[$id]['stock']) {
                    throw new RuntimeException('A cart item is unavailable or has insufficient stock. Please update your cart.');
                }
                $p = $products[$id]; $total += $qty * (float)$p['price'];
                $lines[] = [$id, $p['name'], $qty, $p['price']];
            }
            $stmt = $pdo->prepare("INSERT INTO orders (user_id,total_amount,shipping_address,phone,payment_method) VALUES (?,?,?,?, 'Cash on Delivery')");
            $stmt->execute([current_user()['id'], $total, $address, $phone]);
            $orderId = (int)$pdo->lastInsertId();
            $insertItem = $pdo->prepare("INSERT INTO order_items (order_id,product_id,product_name,quantity,price) VALUES (?,?,?,?,?)");
            $reduce = $pdo->prepare("UPDATE products SET stock=stock-? WHERE id=? AND stock>=?");
            foreach ($lines as [$id,$name,$qty,$price]) {
                $insertItem->execute([$orderId,$id,$name,$qty,$price]);
                $reduce->execute([$qty,$id,$qty]);
                if ($reduce->rowCount() !== 1) throw new RuntimeException('Stock changed. Please try again.');
            }
            $pdo->commit();
            $_SESSION['cart'] = [];
            set_flash('Order placed successfully. Your order number is #' . $orderId . '.');
            redirect('orders.php');
        } catch (Throwable $ex) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            $error = $ex instanceof RuntimeException ? $ex->getMessage() : 'Checkout failed. Please try again.';
        }
    }
}
$page_title = 'Checkout';
require 'header.php';
?>
<div class="form-card">
<h1>Checkout</h1>
<?php if ($error): ?><div class="alert error"><?= e($error) ?></div><?php endif; ?>
<form method="post">
<?= csrf_field() ?>
<label>Shipping Address<textarea name="shipping_address" required><?= e($_POST['shipping_address'] ?? '') ?></textarea></label>
<label>Phone Number<input name="phone" required maxlength="30" value="<?= e($_POST['phone'] ?? '') ?>"></label>
<p>Payment method: <strong>Cash on Delivery</strong></p>
<button class="full">Place Order</button>
</form>
</div>
<?php require 'footer.php'; ?>
