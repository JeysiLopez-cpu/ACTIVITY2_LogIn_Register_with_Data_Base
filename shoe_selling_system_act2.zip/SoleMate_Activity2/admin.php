<?php
require_once 'config.php';
require_admin();

$allowedStatuses = ['Pending','Processing','Shipped','Completed','Cancelled'];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = $_POST['action'] ?? '';
    try {
        if ($action === 'save_product') {
            $id = (int)($_POST['id'] ?? 0);
            $name = trim($_POST['name'] ?? '');
            $brand = trim($_POST['brand'] ?? '');
            $category = trim($_POST['category'] ?? '');
            $description = trim($_POST['description'] ?? '');
            $price = filter_var($_POST['price'] ?? '', FILTER_VALIDATE_FLOAT);
            $stock = filter_var($_POST['stock'] ?? '', FILTER_VALIDATE_INT);
            $image = trim($_POST['image_url'] ?? '');
            if ($name === '' || $price === false || $price < 0 || $stock === false || $stock < 0) {
                throw new RuntimeException('Enter a product name, valid non-negative price, and whole-number stock.');
            }
            if ($image !== '' && !filter_var($image, FILTER_VALIDATE_URL)) {
                throw new RuntimeException('Image URL must be a valid URL or left blank.');
            }
            if ($id > 0) {
                $stmt = $pdo->prepare("UPDATE products SET name=?,brand=?,category=?,description=?,price=?,stock=?,image_url=? WHERE id=?");
                $stmt->execute([$name,$brand,$category,$description,$price,$stock,$image ?: null,$id]);
                set_flash('Product updated.');
            } else {
                $stmt = $pdo->prepare("INSERT INTO products (name,brand,category,description,price,stock,image_url) VALUES (?,?,?,?,?,?,?)");
                $stmt->execute([$name,$brand,$category,$description,$price,$stock,$image ?: null]);
                set_flash('Product added.');
            }
        } elseif ($action === 'delete_product') {
            $stmt = $pdo->prepare("UPDATE products SET is_active=0 WHERE id=?");
            $stmt->execute([(int)$_POST['id']]);
            set_flash('Product removed from the shop.');
        } elseif ($action === 'save_user') {
            $id = (int)($_POST['id'] ?? 0);
            $name = trim($_POST['name'] ?? '');
            $email = strtolower(trim($_POST['email'] ?? ''));
            $role = $_POST['role'] ?? 'customer';
            $newPassword = $_POST['new_password'] ?? '';
            if ($name === '' || !filter_var($email,FILTER_VALIDATE_EMAIL) || !in_array($role,['customer','admin'],true)) {
                throw new RuntimeException('Enter a valid name, email, and role.');
            }
            if ($id === 0) {
                if (strlen($newPassword) < 8) throw new RuntimeException('New users need a password of at least 8 characters.');
                $stmt = $pdo->prepare("INSERT INTO users (name,email,password,role) VALUES (?,?,?,?)");
                $stmt->execute([$name,$email,password_hash($newPassword,PASSWORD_DEFAULT),$role]);
                set_flash('User created.');
            } else {
                $target = $pdo->prepare("SELECT role FROM users WHERE id=?");
                $target->execute([$id]); $old = $target->fetch();
                if (!$old) throw new RuntimeException('User not found.');
                if ($id === (int)current_user()['id'] && $role !== 'admin') throw new RuntimeException('You cannot remove your own administrator access.');
                if ($old['role'] === 'admin' && $role !== 'admin') {
                    $count = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE role='admin'")->fetchColumn();
                    if ($count <= 1) throw new RuntimeException('At least one administrator account must remain.');
                }
                if ($newPassword !== '') {
                    if (strlen($newPassword) < 8) throw new RuntimeException('Password must have at least 8 characters.');
                    $stmt = $pdo->prepare("UPDATE users SET name=?,email=?,role=?,password=? WHERE id=?");
                    $stmt->execute([$name,$email,$role,password_hash($newPassword,PASSWORD_DEFAULT),$id]);
                } else {
                    $stmt = $pdo->prepare("UPDATE users SET name=?,email=?,role=? WHERE id=?");
                    $stmt->execute([$name,$email,$role,$id]);
                }
                if ($id === (int)current_user()['id']) {
                    $_SESSION['user']['name'] = $name;
                    $_SESSION['user']['email'] = $email;
                }
                set_flash('User updated.');
            }
        } elseif ($action === 'delete_user') {
            $id = (int)$_POST['id'];
            if ($id === (int)current_user()['id']) throw new RuntimeException('You cannot delete your own account while logged in.');
            $stmt = $pdo->prepare("SELECT role FROM users WHERE id=?");
            $stmt->execute([$id]); $target = $stmt->fetch();
            if (!$target) throw new RuntimeException('User not found.');
            if ($target['role'] === 'admin') {
                $count = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE role='admin'")->fetchColumn();
                if ($count <= 1) throw new RuntimeException('You cannot delete the last administrator.');
            }
            $stmt = $pdo->prepare("DELETE FROM users WHERE id=?");
            $stmt->execute([$id]);
            set_flash('User deleted.');
        } elseif ($action === 'update_order') {
            $status = $_POST['status'] ?? '';
            if (!in_array($status,$allowedStatuses,true)) throw new RuntimeException('Invalid order status.');
            $stmt = $pdo->prepare("UPDATE orders SET status=? WHERE id=?");
            $stmt->execute([$status,(int)$_POST['id']]);
            set_flash('Order status updated.');
        }
    } catch (PDOException $ex) {
        set_flash($ex->getCode() === '23000' ? 'That email address is already in use, or this record is linked to an order.' : 'Database operation failed.', 'error');
    } catch (RuntimeException $ex) {
        set_flash($ex->getMessage(), 'error');
    }
    redirect('admin.php');
}

$editProduct = null;
if (isset($_GET['edit_product'])) {
    $stmt = $pdo->prepare("SELECT * FROM products WHERE id=?");
    $stmt->execute([(int)$_GET['edit_product']]); $editProduct = $stmt->fetch();
}
$editUser = null;
if (isset($_GET['edit_user'])) {
    $stmt = $pdo->prepare("SELECT id,name,email,role FROM users WHERE id=?");
    $stmt->execute([(int)$_GET['edit_user']]); $editUser = $stmt->fetch();
}
$products = $pdo->query("SELECT * FROM products ORDER BY id DESC")->fetchAll();
$users = $pdo->query("SELECT id,name,email,role,created_at FROM users ORDER BY id DESC")->fetchAll();
$orders = $pdo->query("SELECT o.*,u.name AS customer_name FROM orders o JOIN users u ON u.id=o.user_id ORDER BY o.created_at DESC")->fetchAll();
$page_title = 'Admin Dashboard';
require 'header.php';
?>
<h1>Administrator Dashboard</h1>
<p class="muted">Manage products, user accounts, and customer orders. Admin access is restricted to administrator accounts.</p>
<div class="stats">
<div class="stat"><strong><?= count($products) ?></strong><span>Products</span></div>
<div class="stat"><strong><?= count($users) ?></strong><span>Users</span></div>
<div class="stat"><strong><?= count($orders) ?></strong><span>Orders</span></div>
</div>

<section class="panel">
<h2><?= $editProduct ? 'Edit Product' : 'Add Product' ?></h2>
<form method="post" class="admin-form">
<?= csrf_field() ?><input type="hidden" name="action" value="save_product">
<input type="hidden" name="id" value="<?= (int)($editProduct['id'] ?? 0) ?>">
<label>Product Name<input name="name" required value="<?= e($editProduct['name'] ?? '') ?>"></label>
<label>Brand<input name="brand" value="<?= e($editProduct['brand'] ?? '') ?>"></label>
<label>Category<input name="category" value="<?= e($editProduct['category'] ?? '') ?>"></label>
<label>Price (₱)<input type="number" name="price" min="0" step="0.01" required value="<?= e($editProduct['price'] ?? '') ?>"></label>
<label>Stock<input type="number" name="stock" min="0" step="1" required value="<?= e($editProduct['stock'] ?? '0') ?>"></label>
<label>Image URL (optional)<input type="url" name="image_url" value="<?= e($editProduct['image_url'] ?? '') ?>"></label>
<label class="wide">Description<textarea name="description"><?= e($editProduct['description'] ?? '') ?></textarea></label>
<button><?= $editProduct ? 'Save Changes' : 'Add Product' ?></button>
<?php if ($editProduct): ?><a class="button secondary" href="admin.php">Cancel</a><?php endif; ?>
</form>
</section>

<section class="panel">
<h2>Product Management (Create, Read, Update, Delete)</h2>
<div class="table-wrap"><table><tr><th>Product</th><th>Price</th><th>Stock</th><th>Visibility</th><th>Actions</th></tr>
<?php foreach ($products as $p): ?>
<tr><td><?= e($p['name']) ?><br><small><?= e($p['brand']) ?> / <?= e($p['category']) ?></small></td>
<td>₱<?= number_format((float)$p['price'],2) ?></td><td><?= (int)$p['stock'] ?></td><td><?= $p['is_active'] ? 'Active' : 'Archived' ?></td>
<td class="actions"><a href="admin.php?edit_product=<?= (int)$p['id'] ?>">Edit</a>
<?php if ($p['is_active']): ?><form method="post" onsubmit="return confirm('Remove this product from the shop?')"><?= csrf_field() ?><input type="hidden" name="action" value="delete_product"><input type="hidden" name="id" value="<?= (int)$p['id'] ?>"><button class="danger">Delete</button></form><?php endif; ?></td></tr>
<?php endforeach; ?></table></div>
</section>

<section class="panel">
<h2><?= $editUser ? 'Edit User' : 'Create User' ?></h2>
<form method="post" class="admin-form">
<?= csrf_field() ?><input type="hidden" name="action" value="save_user"><input type="hidden" name="id" value="<?= (int)($editUser['id'] ?? 0) ?>">
<label>Full Name<input name="name" required value="<?= e($editUser['name'] ?? '') ?>"></label>
<label>Email<input type="email" name="email" required value="<?= e($editUser['email'] ?? '') ?>"></label>
<label>Role<select name="role"><option value="customer" <?= (($editUser['role'] ?? 'customer')==='customer')?'selected':'' ?>>Customer</option><option value="admin" <?= (($editUser['role'] ?? '')==='admin')?'selected':'' ?>>Administrator</option></select></label>
<label><?= $editUser ? 'New Password (leave blank to keep current)' : 'Password (minimum 8 characters)' ?><input type="password" name="new_password" <?= $editUser ? '' : 'required minlength="8"' ?> minlength="8"></label>
<button><?= $editUser ? 'Update User' : 'Create User' ?></button>
<?php if ($editUser): ?><a class="button secondary" href="admin.php">Cancel</a><?php endif; ?>
</form>
</section>

<section class="panel">
<h2>User Management (Create, Read, Update, Delete)</h2>
<div class="table-wrap"><table><tr><th>Name</th><th>Email</th><th>Role</th><th>Registered</th><th>Actions</th></tr>
<?php foreach ($users as $u): ?>
<tr><td><?= e($u['name']) ?></td><td><?= e($u['email']) ?></td><td><?= e(ucfirst($u['role'])) ?></td><td><?= e($u['created_at']) ?></td>
<td class="actions"><a href="admin.php?edit_user=<?= (int)$u['id'] ?>">Edit</a>
<form method="post" onsubmit="return confirm('Permanently delete this user?')"><?= csrf_field() ?><input type="hidden" name="action" value="delete_user"><input type="hidden" name="id" value="<?= (int)$u['id'] ?>"><button class="danger">Delete</button></form></td></tr>
<?php endforeach; ?></table></div>
</section>

<section class="panel">
<h2>Order Management</h2>
<div class="table-wrap"><table><tr><th>Order</th><th>Customer</th><th>Total</th><th>Date</th><th>Status</th><th>Update</th></tr>
<?php foreach ($orders as $o): ?>
<tr><td>#<?= (int)$o['id'] ?></td><td><?= e($o['customer_name']) ?></td><td>₱<?= number_format((float)$o['total_amount'],2) ?></td><td><?= e($o['created_at']) ?></td><td><?= e($o['status']) ?></td>
<td><form method="post" class="inline-form"><?= csrf_field() ?><input type="hidden" name="action" value="update_order"><input type="hidden" name="id" value="<?= (int)$o['id'] ?>"><select name="status"><?php foreach ($allowedStatuses as $s): ?><option <?= $o['status']===$s?'selected':'' ?>><?= e($s) ?></option><?php endforeach; ?></select><button>Save</button></form></td></tr>
<?php endforeach; ?></table></div>
</section>
<?php require 'footer.php'; ?>
