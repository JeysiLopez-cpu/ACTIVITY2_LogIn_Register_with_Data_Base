<?php
require_once 'config.php';
$page_title = 'Shop Shoes';
$q = trim($_GET['q'] ?? '');
$sql = "SELECT * FROM products WHERE is_active = 1";
$params = [];
if ($q !== '') {
    $sql .= " AND (name LIKE ? OR brand LIKE ? OR category LIKE ?)";
    $like = '%' . $q . '%';
    $params = [$like, $like, $like];
}
$sql .= " ORDER BY created_at DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$products = $stmt->fetchAll();
require 'header.php';
?>
<section class="hero">
    <p class="eyebrow">STEP INTO COMFORT</p>
    <h1>Find your next favorite pair.</h1>
    <p>Everyday comfort. Simple style. Great value.</p>
</section>
<form class="search" method="get">
    <input name="q" value="<?= e($q) ?>" placeholder="Search shoes, brand, or category">
    <button>Search</button>
</form>
<h2>Our Shoes</h2>
<div class="grid">
<?php foreach ($products as $p): ?>
    <article class="product">
        <?php if (!empty($p['image_url'])): ?>
            <img src="<?= e($p['image_url']) ?>" alt="<?= e($p['name']) ?>">
        <?php else: ?>
            <div class="shoe-placeholder">👟</div>
        <?php endif; ?>
        <div class="product-body">
            <small><?= e($p['brand']) ?> · <?= e($p['category']) ?></small>
            <h3><?= e($p['name']) ?></h3>
            <p><?= e($p['description']) ?></p>
            <strong>₱<?= number_format((float)$p['price'], 2) ?></strong>
            <p class="muted">Stock: <?= (int)$p['stock'] ?></p>
            <?php if ((int)$p['stock'] > 0): ?>
                <form method="post" action="cart.php">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="add">
                    <input type="hidden" name="product_id" value="<?= (int)$p['id'] ?>">
                    <button class="full">Add to Cart</button>
                </form>
            <?php else: ?><button class="full" disabled>Out of Stock</button><?php endif; ?>
        </div>
    </article>
<?php endforeach; ?>
<?php if (!$products): ?><p>No shoes found.</p><?php endif; ?>
</div>
<?php require 'footer.php'; ?>
