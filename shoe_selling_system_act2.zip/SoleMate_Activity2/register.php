<?php
require_once 'config.php';
if (is_logged_in()) redirect('index.php');
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $name = trim($_POST['name'] ?? '');
    $email = strtolower(trim($_POST['email'] ?? ''));
    $password = $_POST['password'] ?? '';
    if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($password) < 8) {
        $error = 'Enter a name, valid email, and password with at least 8 characters.';
    } else {
        try {
            $stmt = $pdo->prepare("INSERT INTO users (name,email,password,role) VALUES (?,?,?,'customer')");
            $stmt->execute([$name, $email, password_hash($password, PASSWORD_DEFAULT)]);
            set_flash('Account created. You can now log in.');
            redirect('login.php');
        } catch (PDOException $e) {
            $error = $e->getCode() === '23000' ? 'That email is already registered.' : 'Registration failed.';
        }
    }
}
$page_title = 'Register';
require 'header.php';
?>
<div class="form-card">
<h1>Create Account</h1>
<?php if ($error): ?><div class="alert error"><?= e($error) ?></div><?php endif; ?>
<form method="post">
<?= csrf_field() ?>
<label>Full Name<input name="name" required maxlength="100" value="<?= e($_POST['name'] ?? '') ?>"></label>
<label>Email<input type="email" name="email" required value="<?= e($_POST['email'] ?? '') ?>"></label>
<label>Password<input type="password" name="password" minlength="8" required></label>
<button class="full">Register</button>
</form>
<p>Already registered? <a href="login.php">Log in</a>.</p>
</div>
<?php require 'footer.php'; ?>
