<?php
$page_title = $page_title ?? 'SoleMate Shoe Store';
$flash = get_flash();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($page_title) ?> | SoleMate</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<header class="topbar">
    <a class="brand" href="index.php">Sole<span>Mate</span></a>
    <nav>
        <a href="index.php">Shop</a>
        <?php if (is_logged_in()): ?>
            <a href="cart.php">Cart</a>
            <a href="orders.php">My Orders</a>
            <?php if (($_SESSION['user']['role'] ?? '') === 'admin'): ?>
                <a href="admin.php">Admin</a>
            <?php endif; ?>
            <span class="nav-user">Hi, <?= e($_SESSION['user']['name']) ?></span>
            <a href="logout.php">Logout</a>
        <?php else: ?>
            <a href="login.php">Login</a>
            <a href="register.php">Register</a>
        <?php endif; ?>
    </nav>
</header>
<main class="container">
<?php if ($flash): ?>
    <div class="alert <?= e($flash['type']) ?>"><?= e($flash['message']) ?></div>
<?php endif; ?>
