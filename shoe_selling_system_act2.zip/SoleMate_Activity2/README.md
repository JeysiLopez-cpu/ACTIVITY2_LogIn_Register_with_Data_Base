# SoleMate Shoe Selling System — Activity #2

A PHP and MySQL shoe store with customer accounts, a shopping cart, checkout, order history, administrator access control, user management, and product/order management.

## Requirements
- XAMPP (Apache, PHP 8.0+ and MySQL/MariaDB)
- Web browser
- phpMyAdmin

## Installation
1. Copy the `SoleMate_Activity2` folder into your XAMPP `htdocs` folder.
2. Start Apache and MySQL from the XAMPP Control Panel.
3. Open `http://localhost/phpmyadmin`.
4. Import `database.sql`.
5. Check the database settings in `config.php` (`DB_HOST`, `DB_NAME`, `DB_USER`, `DB_PASS`).
6. Open `http://localhost/SoleMate_Activity2/`.

## Create the first administrator
1. Register a normal account using the website.
2. In phpMyAdmin, open the `solemate_db` database and run this SQL, replacing the email with the account you registered:

```sql
UPDATE users SET role = 'admin' WHERE email = 'your-email@example.com';
```

3. Log out and log in again. The Admin link should appear in the navigation.

## Activity #2 requirements
- **Access Control:** customer pages require login where appropriate; `admin.php` checks the session role on the server. Customers cannot access administrator actions by changing a URL.
- **User Management:** administrators can create, view, edit, change roles/passwords, and delete accounts. The system prevents deleting the current administrator or removing/deleting the last administrator.
- **CRUD:** administrators can create, read, update, and archive products. Administrators can also manage users and update order statuses.

## Security included
- PDO prepared statements
- `password_hash()` and `password_verify()`
- Session ID regeneration after login
- Server-side role checks
- CSRF tokens on POST forms
- HTML output escaping
- Customer registration always creates a `customer` account (never an administrator)
- Checkout transaction and stock checks

## Important notes
- Product deletion is implemented as an archive (`is_active = 0`) so old order history remains intact.
- Orders are retained when a customer account is deleted only if database constraints allow it; accounts linked to orders are protected from deletion.
- This is a local school project. Before public deployment, add production-grade configuration, HTTPS, rate limiting, backups, and further testing.

## Default local database
- Database: `solemate_db`
- MySQL username: `root`
- MySQL password: blank by default in XAMPP; change `config.php` if yours differs.
